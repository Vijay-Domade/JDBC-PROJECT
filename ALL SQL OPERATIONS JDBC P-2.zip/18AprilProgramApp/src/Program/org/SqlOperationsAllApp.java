package Program.org;
import java.util.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;

public class SqlOperationsAllApp {

	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
		Scanner xyz=new Scanner(System.in);
		FileInputStream inf=new FileInputStream("F:\\New folder (2)\\imp.properties");		
	    Properties p=new Properties();
	    p.load(inf);
	    String driverClass=p.getProperty("driver");
	    String url=p.getProperty("url");
	    String username=p.getProperty("username");
	    String password=p.getProperty("password");
	    Class.forName(driverClass);
	    Connection conn=DriverManager.getConnection(url,username,password);
	    do
	    {
	    	System.out.println("1:Insert the records in table");
	    	System.out.println("2:Delete records using id");
	    	System.out.println("3:Update records using name");
	    	System.out.println("4:Display the records");
	    	System.out.println("5:Display records using salary");
	    	System.out.println("6:Display records start r and ends with sh");
	    	System.out.println("7:Search the name");
	    	System.out.println("8:sort the data in descending order");
	    	System.out.println("Enter your choice");
	    	int choice=xyz.nextInt();
	    	switch(choice)
	    	{
	    	case 1:
	    		if(conn!=null)
	    		{
	    	    	
	    			boolean flag=false;
	    	    	System.out.println("Enter id,name and salary");
	    	    	
	    	    	int id=xyz.nextInt();
	    	    	xyz.nextLine();
	    	    	String name=xyz.nextLine();
	    	    	int salary=xyz.nextInt();
	    	    	PreparedStatement ps=conn.prepareStatement("insert into details values(?,?,?)");
	    	    	ps.setInt(1,id);
	    	    	ps.setString(2, name);
	    	    	ps.setInt(3, salary);
	    	    	int value=ps.executeUpdate();
	    	    	if(value>0)
	    	    	{
	    	    		flag=true;
	    	    	}
	    	    	System.out.println(flag==true ? "Data saves successfully...":"Data not saved");


	    		
	    		}
	    		else
	    		{
	    	    	System.out.println("Not connected");

	    		}
	    		break;
	    	case 2:
	    		if(conn!=null)
	    		{
	    		 boolean flag=false;
    	    	 System.out.println("Enter id for delete");
    	    	 int id=xyz.nextInt();
    	    	 PreparedStatement ps=conn.prepareStatement("delete from details where id=?");
    	    	 ps.setInt(1, id);
    	    	 int value=ps.executeUpdate();
    	    	 if(value>0)
    	    	 {
    	    		flag=true;
    	    	 }
    	    	 System.out.println(flag==true ? "Data delete successfully...":"Data not delete");
	    		}
	    		else
	    		{
	    			
	    	    	System.out.println("Not connected");
	    	    	
	    		}
	    		break;
	    	case 3:
	    		if(conn!=null)
	    		{
	    			boolean flag=false;
	    			System.out.println("Enter name where update want to execute");
	    			xyz.nextLine();
	    			String name=xyz.nextLine();
	    			System.out.println("Enter updated id ");
	    			int id=xyz.nextInt();
	    			System.out.println("Enter updated salary");
	    			int salary=xyz.nextInt();
	    			PreparedStatement ps=conn.prepareStatement("update details set id=?,salary=? where name=?");
                    ps.setInt(1,id);
                    ps.setInt(2, salary);
                    ps.setString(3, name);
                    int value=ps.executeUpdate();
                    if(value>0)
                    {
                    	flag=true;
                    }
	    			System.out.println(flag==true ? "Data update successfully..":"Data not update");
	    		}
	    		else
	    		{
	    			System.out.println("Not connected");
	    		}
	    		break;
	    	case 4:
	    		if(conn!=null)
	    		{
	    			PreparedStatement ps=conn.prepareStatement("select *from details");
	    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    			ResultSet r=ps.executeQuery();
	    			while(r.next())
	    			{
		    			System.out.println(r.getInt("id")+"\t"+r.getString("name")+"\t"+r.getInt("salary"));

	    			}
	    		}
	    		else
	    		{
	    			System.out.println("Not connected");
	    		}
	    		break;
	    	case 5:
	    		if(conn!=null)
	    		{
	    			System.out.println("Enter salary for records");
	    			int salary=xyz.nextInt();
	    			PreparedStatement ps=conn.prepareStatement("select *from details where salary>=?");
	    			ps.setInt(1, salary);
	    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    			ResultSet r=ps.executeQuery();
	    			while(r.next())
	    			{
	    				System.out.println(r.getInt("id")+"\t"+r.getString("name")+"\t"+r.getInt("salary"));
	    			}
	    		}
	    		else
	    		{
	    			System.out.println("Not connected");
	    		}
	    		break;
	    	case 6:
	    		if(conn!=null)
	    		{
	    		 PreparedStatement ps=conn.prepareStatement("select *from details where name like 'r%sh'");
	    		 System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    			ResultSet r=ps.executeQuery();
	    			while(r.next())
	    			{
	    				System.out.println(r.getInt("id")+"\t"+r.getString("name")+"\t"+r.getInt("salary"));
	    			}
	    		}
	    		else
	    		{
	    			System.out.println("Not connected");
	    		}
	    		break;
	    	case 7:
	    		if(conn!=null)
	    		{
	    			System.out.println("Enter name for search");
	    			xyz.nextLine();
	    			String name2=xyz.nextLine();
	    			PreparedStatement ps=conn.prepareStatement("select *from details where name like ?");
	    			ps.setString(1,name2);
	    			ResultSet rs=ps.executeQuery();
	    			if(rs.next())
	    			{
	    				System.out.println("Name found...");
	    				 rs=ps.executeQuery();
		    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
		    			while(rs.next())
		    			{
		   
		    				
		    				System.out.println(rs.getInt("id")+"\t"+rs.getString("name")+"\t"+rs.getInt("salary"));
		    			}
	    			}
	    			else
	    			{
	    				System.out.println("Name not found...");
	    			}
	    		
	    			
	    			/*rs=ps.executeQuery();
	    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    			while(rs.next())
	    			{
	   
	    				
	    				System.out.println(rs.getInt("id")+"\t"+rs.getString("name")+"\t"+rs.getInt("salary"));
	    			}*/
	    			
	    		}
	    		else
	    		{
	    			System.out.println("Not connected");
	    		}
	    		break;
	    	case 8:
	    		
	    			System.out.println("1:Sort data by Id in descending order");
	    			System.out.println("2:Sort data by Name in descending order");
	    			System.out.println("3:Sort data by Salary in descending order");
	    			System.out.println("Enter Your Choice");
	    			int choice2=xyz.nextInt();
	    	switch(choice2)
	    	{
	    			case 1:
	    				if(conn!=null)
	    		    	{
	    					PreparedStatement ps=conn.prepareStatement("select *from details ORDER BY id DESC");
	    	    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    	    			ResultSet r=ps.executeQuery();
	    	    			while(r.next())
	    	    			{
	    	    				System.out.println(r.getInt("id")+"\t"+r.getString("name")+"\t"+r.getInt("salary"));
	    	    			}
	    	    		}
	    	    		else
	    	    		{
	    	    			System.out.println("Not connected");
	    	    		}
	    				break;
	    			case 2:
	    				if(conn!=null)
	    		    	{
	    					PreparedStatement ps=conn.prepareStatement("select *from details ORDER BY name DESC");
	    	    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    	    			ResultSet r=ps.executeQuery();
	    	    			while(r.next())
	    	    			{
	    	    				System.out.println(r.getInt("id")+"\t"+r.getString("name")+"\t"+r.getInt("salary"));
	    	    			}
	    	    		}
	    	    		else
	    	    		{
	    	    			System.out.println("Not connected");
	    	    		}
	    				break;
	    			case 3:
	    				if(conn!=null)
	    		    	{
	    					PreparedStatement ps=conn.prepareStatement("select *from details ORDER BY salary DESC");
	    	    			System.out.println("Id"+"\t"+"Name"+"\t"+"Salary");
	    	    			ResultSet r=ps.executeQuery();
	    	    			while(r.next())
	    	    			{
	    	    				System.out.println(r.getInt("id")+"\t"+r.getString("name")+"\t"+r.getInt("salary"));
	    	    			}
	    	    		}
	    	    		else
	    	    		{
	    	    			System.out.println("Not connected");
	    	    		}
	    				break;
	    			default:
	    				System.out.println("Wrong Choice");
	    				break;
	    		
	    	}
	    	break;
	    	default :
    			System.out.println("Wrong choice");

	    		break;
	    	
	    	}
	    	
	    }
	    while(true);//infinite loop
	}

}
