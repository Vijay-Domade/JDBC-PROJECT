package Program.org;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class AddHundredApp {
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/n2","root","Vijay@sql123");
	
	if(cn!=null)
	{
		
		FileReader f=new FileReader("F:\\New folder (2)\\hundred.csv");
		BufferedReader b=new BufferedReader(f);
		String line;
		boolean x=false;
		while((line=b.readLine())!=null)
		{
			String columns[]=line.split(",");
			PreparedStatement p=cn.prepareStatement("insert into prgm values(?,?,?)");
			p.setString(1,columns[0]);
			p.setString(2,columns[1]);
			p.setString(3,columns[2]);
			int value=p.executeUpdate();
			if(value>0)
			{
				x=true;
			}
			System.out.println(x==true ? "File loaded successfully.." : "Some problem is there");	
		}
			
	}
	else
	{
		System.out.println("Not Connected");	

	}
 }
}
