package AprApp.org;
import java.sql.*;
import java.io.*;
import java.util.*;

public class PropertyApp {
	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
    FileInputStream inf=new FileInputStream("F:\\New folder (2)\\imp.properties");		
    Properties p=new Properties();
    p.load(inf);
    String driverClass=p.getProperty("driver");
    String url=p.getProperty("url");
    String username=p.getProperty("username");
    String password=p.getProperty("password");
    Class.forName(driverClass);
    Connection conn=DriverManager.getConnection(url,username,password);
    if(conn!=null)
    {
    	System.out.println("Connected");
    	Scanner xyz=new Scanner(System.in);
    	boolean flag=false;
    	System.out.println("Enter name,email and contact");
    	String name=xyz.nextLine();
    	String email=xyz.nextLine();
    	String contact=xyz.nextLine();
    	PreparedStatement p3=conn.prepareStatement("insert  into p2 values(?,?,?)");
    	p3.setString(1,name);
    	p3.setString(2,email);
    	p3.setString(3,contact);
    	int v=p3.executeUpdate();
    	if(v>0)
    	{
    		flag=true;
    	}
 	    System.out.println(flag==true ? "Data saved Successfully..":"Data not Saved");
 	    
    	
    }
    else
    {
    	System.out.println("Not Connected");
    }
    
	}

}
