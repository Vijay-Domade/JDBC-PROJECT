package AprApp.org;

import java.sql.*;
import java.util.*;
public class ProCallingApplication 
{
	public static void main(String[] args) throws SQLException, ClassNotFoundException 
	{
		Scanner xyz=new Scanner(System.in);
		System.out.println("1:Insert data by procedure by directly");
		System.out.println("2:Insert data by procedure by user defined");
		System.out.println("3:Insert data by procedure using class for name");
		System.out.println("Enter Your Choice");
		int ch=xyz.nextInt();
		switch(ch)
		{
		case 1:
			com.mysql.cj.jdbc.Driver d=new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(d);
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/n2","root","Vijay@sql123");
			if(conn!=null)
			{
				CallableStatement stmt=conn.prepareCall("{call sepro(?,?,?)}");
				stmt.setString(1,"ABC");
				stmt.setString(2,"PQR");
				stmt.setString(3,"STV");
				boolean b=stmt.execute();
				if(!b)
				{
					System.out.println("Procedure executed");
				}
				else
				{
					System.out.println("Procedure not execute");

				}
			}
			else
			{
				System.out.println("Not Connected");
			}
			break;
		case 2:
			com.mysql.cj.jdbc.Driver d2=new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(d2);
			Connection conn2=DriverManager.getConnection("jdbc:mysql://localhost:3306/n2","root","Vijay@sql123");
			if(conn2!=null)
			{
				System.out.println("Enter name,email and contact");
				xyz.nextLine();
				String name=xyz.nextLine();
				String email=xyz.nextLine();
				String contact=xyz.nextLine();
				CallableStatement stmt2=conn2.prepareCall("{call sepro(?,?,?)}");
				stmt2.setString(1,name);
				stmt2.setString(2,email);
				stmt2.setString(3,contact);
				boolean b=stmt2.execute();
				if(!b)
				{
					System.out.println("Procedure executed");
				}
				else
				{
					System.out.println("Procedure not executed");
				}
			}
			else
			{
				System.out.println("Not Connected");
			}
			break;
		case 3:
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn3=DriverManager.getConnection("jdbc:mysql://localhost:3306/n2","root","Vijay@sql123");
			if(conn3!=null)
			{
				System.out.println("Enter name,email and contact");
				xyz.nextLine();
				String name2=xyz.nextLine();
				String email2=xyz.nextLine();
				String contact2=xyz.nextLine();
				CallableStatement stmt3=conn3.prepareCall("{call sepro(?,?,?)}");
				stmt3.setString(1,name2);
				stmt3.setString(2,email2);
				stmt3.setString(3,contact2);
				boolean b=stmt3.execute();
				if(!b)
				{
					System.out.println("Procedure Executed....");

				}
				else
				{
					System.out.println("Procedure Not Executed");

				}
			}
			else
			{
				System.out.println("Not connected");

			}
			break;
		default:
			System.out.println("Wrong choice");
			break;
		
		}
	}

}
