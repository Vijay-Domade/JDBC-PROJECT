package AprApp.org;
import java.sql.*;
import java.io.*;
public class AddCSVApp {
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/n2","root","Vijay@sql123");
		if(conn!=null)
		{
			FileReader fr=new FileReader("E:\\IT Course\\April\\register.csv");
			BufferedReader br=new BufferedReader(fr);
			String line;
			boolean b=false;
			while((line=br.readLine())!=null)
			{
				String columns[]=line.split(",");
				PreparedStatement stmt=conn.prepareStatement("insert into practice values(?,?,?)");
				stmt.setString(1,columns[0]);
				stmt.setString(2,columns[1]);
				stmt.setString(3,columns[2]);
				int value=stmt.executeUpdate();
				if(value>0)
				{
					b=true;
				}
			}
			System.out.println(b==true ? "File Loaded Success":"Some Problem is there");
		}
		else
		{
			System.out.println("Not Connected");

		}

	}

}
